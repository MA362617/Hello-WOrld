﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.Auth;
using System.IO;
using System.Configuration;

namespace TopGearBlob
{
    public partial class Form1 : Form
    {
        string storageAccountName = ConfigurationManager.AppSettings["StorageAccountName"];
        string accountAccountKey = ConfigurationManager.AppSettings["AccessKey"];

        StorageCredentials storageCredentials;

        CloudStorageAccount account;
        CloudBlobClient cloudBlobClient;
        CloudBlobContainer cloudBlobContainer;

        public Form1()
        {
            InitializeComponent();
            storageCredentials = new StorageCredentials(storageAccountName, accountAccountKey);
            account = new CloudStorageAccount(storageCredentials, useHttps: true);
            cloudBlobClient = account.CreateCloudBlobClient();
            
            }
            

        

        private void Form1_Load(object sender, EventArgs e)
        {

           


        }

        private void bCreate_Click(object sender, EventArgs e)
        {
            
            string blobContainerName = textBox1.Text; // blob container name should be in lower cases

            cloudBlobContainer = cloudBlobClient.GetContainerReference(blobContainerName);
            
            cloudBlobContainer.CreateIfNotExists();
            var perm = new BlobContainerPermissions();
            perm.PublicAccess = BlobContainerPublicAccessType.Container;
            cloudBlobContainer.SetPermissions(perm);

            MessageBox.Show("Media Box is created");

            OpenFileDialog dialog = new OpenFileDialog();
            dialog.ShowDialog();
            var blobPath = dialog.FileName;
            var blobName = dialog.SafeFileName;

            CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(blobName);
            var fileStream = File.OpenRead(blobPath);
            cloudBlockBlob.UploadFromStream(fileStream);
            MessageBox.Show("File Uploaded");
        }

        private void lstBlobs_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var Blobs = cloudBlobContainer.ListBlobs();
            foreach (var Blob in Blobs)
            {
                lstBlobs.Items.Add(Blob.Uri.AbsoluteUri);
            }
        }
    }
}
